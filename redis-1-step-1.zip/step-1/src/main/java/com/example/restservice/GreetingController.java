package com.example.restservice;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {

	private static final String template = "Hello, %s! Current Count is %d";
	private final AtomicLong counter = new AtomicLong();
    private static String USER_KEY = "User";

    @Autowired
    private RedisTemplate<String, String> redisTemplate;
    
    public int updateCount(String userId) {
    	String currentCount = (String) redisTemplate.opsForHash().get(USER_KEY, userId);
    	int cc = 1;
    	if (currentCount != null) {
    		cc = Integer.parseInt(currentCount) + 1;
    	}
    	redisTemplate.opsForHash().put(USER_KEY, userId, Integer.toString(cc));
    	return cc;
    }

	@GetMapping("/greeting")
	public Greeting greeting(@RequestParam(value = "name", defaultValue = "World") String name) {
		int count = updateCount(name);
		return new Greeting(counter.incrementAndGet(), String.format(template, name, counter.get()));
	}
}
