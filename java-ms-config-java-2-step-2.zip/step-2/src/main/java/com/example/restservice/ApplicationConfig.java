package com.example.restservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;

@Configuration
class ApplicationConfig {

	@Autowired
	private RedisProperties props;

	@Bean
	public LettuceConnectionFactory redisConnectionFactory() {
		RedisStandaloneConfiguration config = new RedisStandaloneConfiguration(props.getHost(), props.getPort());
		//config.setUsername(props.getUsername());
		config.setPassword(props.getPassword());
		return new LettuceConnectionFactory(config);
	}
}