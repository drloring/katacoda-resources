package com.example.restservice;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RedisProperties {
    private int port;
    private String host;
    private String username;
    private String password;

    public RedisProperties(
      @Value("${spring.redis.port}") int port, 
      @Value("${spring.redis.host}") String host,
      @Value("${spring.redis.host}") String username,
      @Value("${spring.redis.host}") String password) {
        this.port = port;
        this.host = host;
        this.username = username;
        this.password = password;
    }

	public int getPort() {
		return port;
	}

	public String getHost() {
		return host;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}
	

    
}