package org.openpolicyagent.voter;

public class OPADataResponse {

    private boolean result;

    public OPADataResponse() {

    }

    public boolean getResult() {
        return this.result;
    }

    @SuppressWarnings("unused")
    public void setResult(boolean result) {
        this.result = result;
    }

}